package com.nischal.book_borrowing_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookBorrowingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
